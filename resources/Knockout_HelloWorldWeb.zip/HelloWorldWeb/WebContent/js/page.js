//concetto ko
//concetto observable
//concetto computed

function AppViewModel() {	
	this.firstName = ko.observable("Alpe");
	this.lastName = ko.observable("Devero");	
    this.result = ko.computed(function() {
    	return this.firstName() + " " + this.lastName();
    }, this);
    
    //creazione di una funzione
    this.toUzzerCase = function(){
    	this.firstName(this.firstName().toUpperCase());
    	this.lastName(this.lastName().toUpperCase());    	
    }
    
    //////////////////////////////////////////////////////////////
   
    var self = this;

    // Non-editable catalog data - would come from the server
    self.availableMeals = [
        { mealName: "Panozzo scandaloso", price: 0 },
        { mealName: "Pasta fredda con avanzi", price: 11.25 },
        { mealName: "Zuppa senza avanzi", price: 290.258 }
    ];    

    // Editable data

    self.seats = ko.observableArray([
        new SeatReservation(this.firstName, self.availableMeals[0]),
        new SeatReservation("Trenk Nappa", self.availableMeals[1]),
        new SeatReservation("Saruele Ciazo", self.availableMeals[2]),
    ]);
    
	self.passengerName = ko.observable("xyz zyx");
	self.meal = ko.observable("");	
	self.surcharge = ko.observable("");
	
    self.formattedPrice = ko.computed(function() {
        var price = self.meal().price;
        return price ? "Eur " + price.toFixed(2) : "Gratis";        
    });
    
    
    //aggiungere un posto
    self.addSeat = function() {
        self.seats.push(
        		new SeatReservation(
        				this.passengerName(), 
        				{ mealName: this.meal().mealName, price: this.meal().price }
        		));
    }
    
    //rimuovere un posto
    self.removeSeat = function(seat) { 
    	self.seats.remove(seat)
    }

    
    self.tunztunz = function(mealName){
    	return mealName.length;
    }
    
    
    
    ////////////////////// esempio mail
    self.folders = ['Archive'];
    self.chosenFolderId = ko.observable();
    self.chosenFolderData = ko.observable();
    
    
     // Behaviours
    self.goToFolder = function(folder) { 
    	self.chosenFolderId(folder); 
    	$.get('/html/mail.json', { folder: folder }, self.chosenFolderData);
    };
        
}

/////////////////////////////////////////////////////////

function SeatReservation(name, initialMeal) {
    var self = this;
    self.name = name;
    self.meal = ko.observable(initialMeal);
}

function displayExample(par){
	return 0<par;
}



// Activates knockout.js
ko.applyBindings(new AppViewModel());